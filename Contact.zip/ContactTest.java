import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
    Contact contact = new Contact("1", "firstname", "lastname", "123567890", "Sample St"); // making the object as a class member so that all the methods can access it

    @Test
    void getContactID() {
        assertEquals("1", contact.getContactID());
    }

    @Test
    void getFirstName() {
        assertEquals("firstname", contact.getFirstName());
    }

    @Test
    void getLastName() {
        assertEquals("lastname", contact.getLastName());
    }

    @Test
    void getPhoneNumber() {
        assertEquals("1234567890", contact.getPhoneNumber());
    }

    @Test
    void getAddress() {
        assertEquals("Sample St", contact.getAddress());
    }

    @Test
    void testToString() {
        assertEquals("Contact [contactID=1, firstname=firstname, lastname=lastname, phonenumber=1234567890, address=Sample St]", contact.toString());
    }

}