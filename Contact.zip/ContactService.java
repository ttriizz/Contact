package contact;

import java.util.ArrayList;

public class ContactService {

//list of contacts

private ArrayList contacts;

// constructor

public ContactService() {

contacts = new ArrayList<>();

}

// Adds contact to list if not already

public boolean addContact(Contact contact){

// checks for contact.

boolean isPresent= false;

for (Contact contactList:contacts) {

if (contactList.equals(contact)) {

isPresent = true;

}

}

// if not found then added.

if (!isPresent) {

contacts.add(contact);

return true;

}

else {

return false;

}

}

// replace IDs if already found

public boolean deleteContact(String contactID) {

for (Contact contactList:contacts) {

if (contactList.getContactID().equals(contactID)) {

contacts.remove(contactList);

return true;

}

}

return false;

}

// update with new contact

public boolean updateContact(String contactID, String firstname, String lastname, String phonenumber, String address) {

for (Contact contactList:contacts) {

if (contactList.getContactID().equals(contactID)) {

if(!firstname.equals("") && !(firstname.length()>10)) {

contactList.setFirstName(firstname);

}

if(!lastname.equals("") && !(lastname.length()>10)) {

contactList.setFirstName(lastname);

}

if(!phonenumber.equals("") && (phonenumber.length()==10)) {

contactList.setFirstName(phonenumber);

}

if(!address.equals("") && !(address.length()>30)) {

contactList.setFirstName(address);

}

return true;

}

}

return false;

}

}