package contact;

//variables

public class Contact {

String contactID;

String firstname;

String lastname;

String phonenumber;

String address;

//constructor

public Contact(String contactID, String firstname, String lastname, String phonenumber, String address) {

super();

this.contactID = contactID;

this.firstname = firstname;

this.lastname = lastname;

this.phonenumber = phonenumber;

this.address = address;

}

// Get ContactID

public String getContactID() {

return contactID;

}

// Set ContactID

public void setContactID(String contactID) {

this.contactID = contactID;

}

// Get firstname

public String getFirstName() {

return firstname;

}

// Set firstname

public void setFirstName(String firstname) {

this.firstname = firstname;

}

// Get lastname

public String getLastName() {

return lastname;

}

// Set lastname

public void setLastName(String lastname) {

this.lastname = lastname;

}

// Get Phonenumber

public String getPhoneNumber() {

return phonenumber;

}

// Set Phonenumber

public void setPhoneNumber(String phonenumber) {

this.phonenumber = phonenumber;

}

// Get Address

public String getAddress() {

return address;

}

// Set Address

public void setAddress(String address) {

this.address = address;

}

// Checking if the two contacts match.

@Override

public String toString() {

return "Contact [contactID=" + contactID + ", firstname=" + firstname + ", lastname=" + lastname + ", phonenumber=" + phonenumber + ", address=" + address + "]";

}

}