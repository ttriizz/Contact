package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

// create test methods

@Test

public void testAdd(){

ContactService cs = new ContactService();

Contact t1 = new Contact("C001", "Henry", "Smithers", "123", "Sample ST");

assertEquals(true, cs.addContact(t1));

}

// delete test methods

@Test

public void testDelete(){

ContactService cs = new ContactService();

Contact t1 = new Contact("C001", "Henry", "Smithers", "123", "Sample ST");

Contact t2 = new Contact("C002", "Jim", "Bob", "456", "Sample ST");

Contact t3 = new Contact("C003", "Kendrick", "Mur", "789", "Sample ST");

cs.addContact(t1);

cs.addContact(t2);

cs.addContact(t3);

assertEquals(true, cs.deleteContact("C002"));

assertEquals(false, cs.deleteContact("C000"));

assertEquals(false, cs.deleteContact("C002"));

}

// test update methods

@Test

public void testUpdate(){

ContactService cs = new ContactService();

Contact t1 = new Contact("C001", "Henry", "Smithers", "123", "Sample ST");

Contact t2 = new Contact("C002", "Jim", "Bob", "456", "Sample ST");

Contact t3 = new Contact("C003", "Kendrick", "Mur", "789", "Sample ST");

cs.addContact(t1);

cs.addContact(t2);

cs.addContact(t3);

assertEquals(true, cs.updateContact("C003", "KendrickFirst", "MurLast", "789", "Sample ST"));

assertEquals(false, cs.updateContact("C004", "KendrickFirst", "MurLast", "789", "Sample ST"));

}

}